#!/bin/bash
set -x
HOST=`hostname`
echo $HOST
DATE=`date "+%m-%d-%Y"`

AWS_ACCESS_KEY_ID="AKIAIQOYFKX2BYLYAGBQ"
AWS_SECRET_ACCESSS_KEY="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"
AWS_DEFAULT_REGION="us-east-1"

echo $AWS_DEFAULT_REGION; export $AWS_DEFAUL_REGION
echo $AWS_ACCESS_KEY_ID; export $AWS_ACCESS_KEY_ID
echo $AWS_SECRET_ACCESS_KEY; export $AWS_SECRET_ACCESS_KEY

mkdir /home/ec2-user/.aws

touch /home/ec2-user/.aws/config
touch /home/ec2-user/.aws/credentials

chown -R ec2-user:ec2-user /home/ec2-user/.aws/*

cat <<EOF > /home/ec2-user/.aws/config
[default]
region = us-east-1
EOF

cat <<EOF > /home/ec2-user/.aws/credentials
[default]
aws_access_key_id = AKIAIQOYFKX2BYLYAGBQ
aws_secret_access_key = 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
EOF

chown -R ec2-user:ec2-user /home/ec2-user/.aws/*


chown -R ec2-user:ec2-user /tmp/report.html
aws s3 cp /tmp/report.html s3://cis-audits/$HOST-CISAUDIT-$DATE.html
