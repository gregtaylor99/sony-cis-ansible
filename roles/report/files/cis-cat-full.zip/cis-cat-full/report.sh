#!/bin/bash
set -x
HOST=`hostname`
echo $HOST

echo "TIME TO RUN CIS AUDIT TOOL"
/home/ec2-user/cis-cat-full/CIS-CAT.sh -a -f -props /home/ec2-user/cis-cat-full/misc/ciscat.properties -b /home/ec2-user/cis-cat-full/benchmarks/CIS_Amazon_Linux_2014.09-2015.03_Benchmark_v1.1.0-xccdf.xml
echo "TIME TO move AUDIT TOOL report"
mv /root/CIS-CAT_Results/*/*.html /home/ec2-user/report.html
rm -rf /root/CIS-CAT_Results
echo "TIME TO install mutt CIS AUDIT TOOL"
yum install mutt -y
echo "TIME TO mutt it to greg CIS AUDIT TOOL"
/usr/bin/mutt -s "CIS Report for $HOST" -a /home/ec2-user/report.html -- greg@qmrcloudops.com < "."
echo "TIME TO archive CIS AUDIT TOOL"
mv /home/ec2-user/report.html /tmp/.
