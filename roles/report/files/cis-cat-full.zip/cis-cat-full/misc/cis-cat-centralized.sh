#!/bin/sh

#
# This script is intended to reside on a centralized file share that is accessible by the computers
# to be assess by CIS-CAT. 
#
# The default configuration of this script expects the following target-facing file structure:
# 
#        /cis
#        /cis/cis-cat-full
#        ...        
#        /cis/cis-cat-full/CISCAT.jar
#        ...
#        /cis/reports
#        /cis/jres
#        /cis/jres/AIX
#        ...
#        /cis/jres/AIX/bin/java
#        ...
#        /cis/jres/Debian
#        /cis/jres/HPUX
#        /cis/jres/Linux
#        /cis/jres/OSX
#        /cis/jres/RedHat
#        /cis/jres/Solaris
#        /cis/jres/SolarisSparc
#        /cis/jres/SUSE

#
#       Note: cis-cat-centralized.sh --make-jre-directories  will create the jres/* directories. However,
#                you will need to download and unzip the appropriate JRE into these folders. JREs can be
#                obtained from the following URLS:
#
#                === IBM AIX === 
#                URL:
#                http://www.ibm.com/developerworks/java/jdk/aix/service.html
# 
#                Notes: 
#                IBM creates a redistributable "latest" JRE .bin. They also have a JRE .tar. 
# 
#                === Linux ===# 
#                URL: http://java.com/en/download/manual.jsp
# 
#                Note: This JRE is expected to work for RedHat, Debian, and SUSE.
# 
#                === Solaris ===# 
#                URL: http://java.com/en/download/manual.jsp
# 
#                Notes: one for SPARC and one for X86
#  
#                === HP-UX ===
#                URL: http://h18012.www1.hp.com/java/
#                URL: https://h20392.www2.hp.com/portal/swdepot/displayProductInfo.do?productNumber=HPUXJAVAHOME
# 
#                === Apple OSX === 
#                URL: http://support.apple.com/downloads/Java_for_Mac_OS_X_10_5_Update_4
#                URL: http://support.apple.com/kb/DL1360
#                URL: http://support.apple.com/kb/DL1421
#

#
# When using a CIS-CAT trial/timed version, users MUST set the TIMED value to '1'
#
TIMED='0'

#
# Modify the following three variables to align with target-facing file structure implemented 
# in your environment.
#
if [ "$TIMED" -eq "1" ]; then
        CISCAT_DIR=/cis/cis-cat-timed
else
        CISCAT_DIR=/cis/cis-cat-full
fi

REPORTS_DIR=/cis/reports
JRE_BASE=/cis/jres

#
# There is no need to make modifications below this point unless you want to override the benchmark profile 
# CIS-CAT uses. The default configuration of this script will cause CIS-CAT to run the "Level 2" equivalent
# profile, which includes all "Level 1" profile checks. 
#

map_to_benchmark()
{
        _DISTRO=$1
        _VER=$2

        case $_DISTRO in
                OSX)
                        # OSX 10.5
                        if [ `expr $_VER \>= 9.0 \& $_VER \< 10.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Apple_OSX_10.5_Benchmark_v.1.1.0.xml"
                                PROFILE1="Level 1 Profile"
                                PROFILE2="Level 2 Profile"
                        fi

                        # OSX 10.6
                        if [ `expr $_VER \>= 10.0 \& $_VER \< 11.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Apple_OSX_10.6_Benchmark_v.1.0.0.xml"
                                PROFILE1="Level 1 Profile"
                                PROFILE2="Level 2 Profile"
                        fi

                        # OSX 10.8
                        if [ `expr $_VER \>= 12.0 \& $_VER \< 13.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Apple_OSX_10.8_Benchmark_v1.3.0.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        # OSX 10.9
                        if [ `expr $_VER \>= 13.0 \& $_VER \< 14.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Apple_OSX_10.9_Benchmark_v1.2.0.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        # OSX 10.10
                        if [ `expr $_VER \>= 14.0 \& $_VER \< 15.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Apple_OSX_10.10_Benchmark_v1.1.0.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        # OSX 10.11
                        if [ `expr $_VER \>= 15.0 \& $_VER \< 16.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Apple_OSX_10.11_Benchmark_v1.0.0.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        ;;
                Debian)
                        if [ `expr $_VER \>= 4 \& $_VER \< 7` -eq 1 ]
                        then
                                BENCHMARK="CIS_Debian_Linux_3_Benchmark_v1.0.0.xml"
                                PROFILE1="debian-level-1-profile"
                                PROFILE2="debian-complete-profile"
                        fi

                        if [ `expr $_VER \>= 7 \& $_VER \< 8` -eq 1 ]
                        then
                                BENCHMARK="CIS_Debian_Linux_7_Benchmark_v1.0.0-xccdf.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        if [ `expr $_VER \>= 8` -eq 1 ]
                        then
                                BENCHMARK="CIS_Debian_Linux_8_Benchmark_v1.0.0-xccdf.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        ;;
                Ubuntu)
                	# Ubuntu 12.04
                        if [ `expr $_VER == 12.04` -eq 1 ]
                        then
				BENCHMARK="CIS_Ubuntu_12.04_LTS_Server_Benchmark_v1.1.0.xml"
				PROFILE1="Level 1"
				PROFILE2="Level 2"
			fi
			
			# Ubuntu 14.04
                        if [ `expr $_VER == 14.04` -eq 1 ]
                        then
				BENCHMARK="CIS_Ubuntu_14.04_LTS_Server_Benchmark_v1.0.0.xml"
				PROFILE1="Level 1"
				PROFILE2="Level 2"
			fi
			
			;;
                HPUX)
                        if [ `expr $_VER \>= 11 \& $_VER \< 12` -eq 1 ]
                        then
                                BENCHMARK="CIS_HP-UX_11i_Benchmark_v1.4.2.xml"
                                PROFILE1="Level 1 Profile"
                                PROFILE2="Level 2 Profile"
                        fi

                        ;;
                AIX)
                        # AIX 4.3 - 5.1
                        if [ `expr $_VER \>= 4.3 \& $_VER \< 5.2` -eq 1 ]
                        then
                                BENCHMARK="CIS_IBM_AIX_4.3-5.1_Benchmark_v1.0.1.xml"
                                PROFILE1="Level 1 Profile"
                                PROFILE2="Level 1 Profile"
                        fi

                        # AIX 5.3 - 6.1
                        if [ `expr $_VER \>= 5.3 \& $_VER \< 6.2` -eq 1 ]
                        then
                                BENCHMARK="CIS_IBM_AIX_5.3-6.1_Benchmark_v1.1.0.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        # AIX 7.1
                        if [ `expr $_VER \>= 7.1 \& $_VER \< 7.2` -eq 1 ]
                        then
                                BENCHMARK="CIS_IBM_AIX_7.1_Benchmark_v1.1.0.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi


                        ;;
                RedHat)
                        # RHEL 4
                        if [ `expr $_VER \>= 4.0 \& $_VER \< 5.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Red_Hat_Enterprise_Linux_4_Benchmark_v1.0.5.xml"
                                PROFILE1="Level 1 Profile"
                                PROFILE2="Level 1 Profile"
                        fi

                        # RHEL 5
                        if [ `expr $_VER \>= 5.0 \& $_VER \< 6.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Red_Hat_Enterprise_Linux_5_Benchmark_v2.2.0-xccdf.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        # RHEL 6
                        if [ `expr $_VER \>= 6.0 \& $_VER \< 7.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Red_Hat_Enterprise_Linux_6_Benchmark_v1.4.0-xccdf.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        # RHEL 7
                        if [ `expr $_VER \>= 7.0 \& $_VER \< 8.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_Red_Hat_Enterprise_Linux_7_Benchmark_v1.1.0-xccdf.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        ;;
                CentOS)
                	# CentOS 6
			if [ `expr $_VER \>= 6.0 \& $_VER \< 7.0` -eq 1 ]
			then
				BENCHMARK="CIS_CentOS_Linux_6_Benchmark_v1.1.0-xccdf.xml"
				PROFILE1="Level 1"
				PROFILE2="Level 2"
			fi
			
                	# CentOS 7
			if [ `expr $_VER \>= 7.0 \& $_VER \< 8.0` -eq 1 ]
			then
				BENCHMARK="CIS_CentOS_Linux_7_Benchmark_v1.1.0-xccdf.xml"
				PROFILE1="Level 1"
				PROFILE2="Level 2"
			fi
			
                        ;;
                SUSE)
                        # SUSE 12
                        if [ `expr $_VER \>= 12.0 \& $_VER \< 13.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_SUSE_Linux_Enterprise_Server_12_Benchmark_v1.0.0-xccdf.xml"
				PROFILE1="Level 1"
				PROFILE2="Level 2"
                        fi

                        # SUSE 11
                        if [ `expr $_VER \>= 11.0 \& $_VER \< 12.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_SUSE_Linux_Enterprise_Server_11_Benchmark_v1.1.0-xccdf.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        fi

                        # SUSE 10
                        if [ `expr $_VER \>= 10.0 \& $_VER \< 11.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_SUSE_Linux_Enterprise_Server_10_Benchmark_v2.0.0.xml"
                                PROFILE1="profile-reduced"
                                PROFILE2="profile-complete"
                        fi

                        # SUSE 9
                        if [ `expr $_VER \>= 9.0 \& $_VER \< 10.0` -eq 1 ]
                        then
                                BENCHMARK="CIS_SUSE_Linux_Enterprise_Server_9_Benchmark_v1.0.0.xml"
                                PROFILE1="profile-reduced"
                                PROFILE2="profile-complete"
                        fi

                        ;;

                Solaris)

                        # Solaris 11, 11.1, 11.2
                        if [ `expr $_VER == 5.11` -eq 1 ]
                        then
                                if [ `expr $_OSV == 11.1` -eq 1 ]
                                then
                                        BENCHMARK="CIS_Oracle_Solaris_11.1_Benchmark_v1.0.0.xml"
                                elif [ `expr $_OSV == 11.2` -eq 1 ]
                                then
                                        BENCHMARK="CIS_Oracle_Solaris_11.2_Benchmark_v1.1.0.xml"
                                else
                                        BENCHMARK="CIS_Oracle_Solaris_11_Benchmark_v1.1.0.xml"
                                fi
                                
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        
                        # Solaris 10
                        elif [ `expr $_VER == 5.10` -eq 1 ]
                        then
                                BENCHMARK="CIS_Oracle_Solaris_10_Benchmark_v5.2.0.xml"
                                PROFILE1="Level 1"
                                PROFILE2="Level 2"
                        else
                                # Solaris 2.5.1-9
                                BENCHMARK="CIS_Oracle_Solaris_2.5.1-9_Benchmark_v1.3.0.xml"
                                PROFILE1="Level 1 Profile"
                                PROFILE2="Level 1 Profile"
                        fi

                        ;;

                        #
                        # CIS_Slackware_Linux_10.2_Benchmark_v1.1.0.xml SlackWare benchmark is not integrated.
                        #       

#               *)
#
#
#                       ;;
        esac
}

detect_os_variant()
{
        # when invoked with no option, `uname` assumes -s
        case `uname` in
                Linux)
                ### RedHat and variants ###
                        if [ -f /etc/redhat-release ]
                        then
                                case `awk {'print $1'} /etc/redhat-release` in
                                        Red)
                                                DISTRO='RedHat' ;;
                                        CentOS)
                                                DISTRO='CentOS' ;;
                                esac
                                VER=`egrep -o "([[:digit:]]\.?)+" /etc/redhat-release`

                ### SuSE and variants ###
                        elif [ -f /etc/SuSE-release ]
                        then
                                DISTRO='SUSE'
                                VER=`grep VERSION /etc/SuSE-release | awk '{print $NF}'`.`grep PATCHLEVEL /etc/SuSE-release | awk '{print $NF}'`

		### Debian and variants ###
                        elif [ -f /etc/debian_version ]
                        then
                                DISTRO='Debian'
                                VER=`egrep -o "([[:digit:]]\.?)+" /etc/debian_version`

                                # Ubuntu appears to not use numbers...
                                if [ ! $VER ]
                                then
                                        DISTRO='Ubuntu'
                                        VER=`egrep "VERSION_ID=.*" /etc/os-release | egrep -o "([[:digit:]]\.?)+"`
                                fi
                        else
                                DISTRO='Linux'
                        fi
                ;;
                HP-UX)
                        DISTRO="HPUX"
                        VER=`uname -v | cut -d"." -f 2`
                ;;
                AIX)
                        DISTRO="AIX"
                        VER=`uname -v`.`uname -r`
                ;;
                Darwin)
                        DISTRO='OSX'
                        VER=`uname -r`
                ;;
                SunOS)
                        DISTRO='Solaris'
                        VER=`uname -r`
                        OSV=`uname -v`
                ;;

#               *)
#                       DISTRO='<Unknown_Platform>'
#                       VER='<Unknown_Version>'
        esac
}

make_jre_directories()
{

        JRES_DIR=jres

        DISTROS='RedHat CentOS SUSE Debian Ubuntu Linux HPUX AIX OSX Solaris'

        if [ -e "$JRES_DIR" -a -d "$JRES_DIR" ]; then
                echo "Directory '$JRES_DIR' already exists - continuing."
        else                
                mkdir "$JRES_DIR";

                if [ $? -eq 1 ]; then
                        echo "ERROR: Unable to create directory '$JRES_DIR'. Ensure you have write permission on the current directory.";
                        exit 1;
                else
                        echo "Created directory '$JRES_DIR'."        
                fi                       
        fi

        for d in $DISTROS; do 

                if [ -e "$JRES_DIR/$d" ]; then
                        echo "Directory '$JRES_DIR/$d' already exists - continuing."
                        continue;
                else
                        mkdir "$JRES_DIR/$d"                        

                        if [ $? -eq 1 ]; then
                                echo "ERROR: Unable to create directory '$JRES_DIR/$d'. Ensure you have write permission on '$JRES_DIR'.";
                                exit 1;
                        else
                                echo "Created directory '$JRES_DIR/$d'."        
                        fi
                fi                               
        done
}

# determine if this execution is setting up jre directories or not. 
if [ $1 ]; then
	if [ "$1" == "--make-jre-directories" ]; then
		make_jre_directories;
		exit 1;
	fi
fi

SSLF='0'
BENCHMARK='<UnknownBenchmark>'
PROFILE1='<UnknownProfile>'
PROFILE2='<UnknownProfile>'
DISTRO='<UnknownDistribution>'
VER='<UnknownVersion>'
OSV='<UnknownOSVersion>'

# sets DISTRO and VER
detect_os_variant

JAVA_HOME=$JRE_BASE/$DISTRO

# sets BENCHMARK and PROFILE
map_to_benchmark $DISTRO $VER

#
# When using the timed version of CIS-CAT, the benchmarks are stored in the jar, 
# so the path to the benchmark needs to indicate the resource path, for example
# /benchmarks/%BENCHMARK%
#
# Timed Version:
#  CISCAT_OPTS=" -a -s -x -r $REPORTS_DIR -b /benchmarks/$BENCHMARK "
#
# Full Version:
#  CISCAT_OPTS=" -a -s -x -r $REPORTS_DIR -b $CISCAT_DIR/benchmarks/$BENCHMARK "
#
if [ "$TIMED" -eq "1" ]; then
        CISCAT_OPTS=" -a -s -x -r $REPORTS_DIR -b /benchmarks/$BENCHMARK "
else
        CISCAT_OPTS=" -a -s -x -r $REPORTS_DIR -b $CISCAT_DIR/benchmarks/$BENCHMARK "
fi

CISCAT_CMD="$JAVA_HOME/bin/java -Xmx768M -jar $CISCAT_DIR/CISCAT.jar $CISCAT_OPTS"

echo
echo "Detected OS as $DISTRO $VER"
echo "Using JRE located at '$JAVA_HOME'"
echo "Using CISCAT located at '$CISCAT_DIR/CISCAT.jar'"
echo "Using Benchmark '$BENCHMARK'"
if [ "$SSLF" -eq "1" ]; then
	echo "Using Profile '$PROFILE2'"
else
	echo "Using Profile '$PROFILE1'"
fi
echo "Storing Reports at '$REPORTS_DIR'"
echo

GOOD=1

if [ ! -d "$CISCAT_DIR" ]; then
        echo "ERROR: CISCAT_DIR does not point to a valid directory"
        GOOD=0
fi

if [ ! -e "$CISCAT_DIR/CISCAT.jar" ]; then
        echo "ERROR: CISCAT.jar does not exist at '$CISCAT_DIR/CISCAT.jar'"
        GOOD=0
fi

if [ ! -d "$REPORTS_DIR" ]; then
        echo "ERROR: REPORTS_DIR does not point to a valid directory"
        GOOD=0
fi

if [ ! -d "$JRE_BASE" ]; then
        echo "ERROR: JRE_BASE does not point to a valid directory"
        GOOD=0
fi

if [ ! -d "$JAVA_HOME" ]; then
        echo "ERROR: JAVA_HOME does not point to a valid directory"
        GOOD=0
fi

if [ ! -e "$JAVA_HOME/bin/java" ]; then
        echo "ERROR: java does not exist at '$JAVA_HOME/bin/java'"
        GOOD=0
fi

if [ "$TIMED" -eq "0" ]; then
        if [ ! -e "$CISCAT_DIR/benchmarks/$BENCHMARK" ]; then
                echo "ERROR: Benchmark '$BENCHMARK' does not exist in directory '$CISCAT_DIR/benchmarks'  "
                GOOD=0
        fi
fi

if [ "$GOOD" -eq "1" ]; then
        echo
        echo "Running CISCAT with the following options: "
        echo
        
        if [ "$SSLF" -eq "1" ]; then
		echo "  $CISCAT_OPTS" -p "$PROFILE2"
		echo

		$CISCAT_CMD -p "$PROFILE2"
	else
		echo "  $CISCAT_OPTS" -p "$PROFILE1"
		echo
		
		$CISCAT_CMD -p "$PROFILE1"
	fi
else
        echo
        echo "Please review errors listed above, make corrective actions, and retry."
        echo
fi
